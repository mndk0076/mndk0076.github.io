package kenneth.kennethassign3;

import android.app.ProgressDialog;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.LayoutInflaterCompat;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class KennethFragment extends Fragment {
    private int mCounter = 0;
    Button btn, downloadBtn;
    ImageView imageView;
    TextView counter;
    RatingBar ratingBar;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstances){

        return inflater.inflate(R.layout.kenneth_image,container,false);
    }

    public void onActivityCreated(Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);

        final String image_url = "http://www.planwallpaper.com/static/images/b807c2282ab0a491bd5c5c1051c6d312_rP0kQjJ.jpg";

        counter = (TextView)getView().findViewById(R.id.counter);
        btn = (Button)getView().findViewById(R.id.btn);
        downloadBtn = (Button)getView().findViewById(R.id.downloadbtn);
        imageView = (ImageView)getView().findViewById(R.id.imageView);
        ratingBar = (RatingBar)getView().findViewById(R.id.ratingBar);
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                Toast.makeText(getActivity(),String.valueOf(rating), Toast.LENGTH_SHORT).show();
            }
        });

        downloadBtn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                DowloadTask dowloadTask = new DowloadTask();
                dowloadTask.execute(image_url);

            }
        });


        btn.setOnClickListener(new ViewPager.OnClickListener(){
            @Override
            public void onClick(View view){
                mCounter++;
                counter.setText(Integer.toString(mCounter));
            }
        });
    }

    class DowloadTask extends AsyncTask<String,Integer,String>{

        ProgressDialog progressDialog;
        @Override
        protected void onPreExecute() {
            progressDialog = new ProgressDialog(getActivity());
            progressDialog.setTitle("Download in Progress...");
            progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progressDialog.setMax(100);
            progressDialog.setProgress(0);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... params) {
            String path = params[0];
            int file_length = 0;
            try {
                URL url = new URL(path);
                URLConnection urlConnection = url.openConnection();
                urlConnection.connect();
                file_length = urlConnection.getContentLength();
                File new_folder = new File("photoalbum");
                if(!new_folder.exists()){
                    new_folder.mkdir();
                }

                File input_file = new File(new_folder,"downloaded_images.jpg");
                InputStream inputStream = new BufferedInputStream(url.openStream(), 8192);
                byte[] data = new byte[1024];
                int total = 0;
                int count = 0;
                OutputStream outputStream = new FileOutputStream(input_file);
                while((count = inputStream.read(data))!= -1){
                    total+=count;
                    outputStream.write(data,0,count);
                    int progress = (int) total*100/file_length;
                    publishProgress(progress);
                }
                inputStream.close();
                outputStream.close();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return "Download Complete.";
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            progressDialog.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(String result) {
            progressDialog.hide();
            Toast.makeText(getActivity(),result,Toast.LENGTH_LONG).show();
            String path = "photoalbum/downloaded_image.jpg";
            imageView.setImageDrawable(Drawable.createFromPath(path));
        }
    }

}
