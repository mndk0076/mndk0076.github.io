/**
 * Created by Kristina on 2016-11-27.
 */

public class CustomAdapter {
}
