package mendozaassign1.prototypelabflow;

//Protoype Lab Flow by V/X Estate
//Kenneth Mendoza(N00587007)
//Sukhdeep Sehra (N01046228)
//Matheus Almeida (N00739768)

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;


public class LoginActivity extends AppCompatActivity {
    EditText etUsername, etPassword;
    String login_name, login_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        android.support.v7.app.ActionBar ab = getSupportActionBar();
        ab.setLogo(R.mipmap.ic_launcher);
        ab.setTitle(" " + getString(R.string.login_screen));
        ab.setDisplayUseLogoEnabled(true);
        ab.setDisplayShowHomeEnabled(true);


        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
        final Button btnLogin = (Button) findViewById(R.id.btnLogin);
        final TextView tvRegisterLink = (TextView) findViewById(R.id.tvRegisterLink);

        tvRegisterLink.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                LoginActivity.this.startActivity(intent);
            }
        });
    }

    public void userLogin(View view){
        login_name = etUsername.getText().toString();
        login_pass = etPassword.getText().toString();
        String method = "login";
        RegisterRequest registerRequest = new RegisterRequest(this);
        registerRequest.execute(method, login_name, login_pass);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.generic_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {
            case R.id.theme:
              //  Toast.makeText(this, "changing theme", Toast.LENGTH_SHORT).show();
         //       int id = item.getItemId();


                if(item.isChecked()){
                    item.setChecked(false);
                    Toast.makeText(this, (R.string.change_theme1), Toast.LENGTH_SHORT).show();
            //        setTheme(R.id.AppTheme);
                    break;
                }else{
                    item.setChecked(true);
                    Toast.makeText(this, (R.string.change_theme2), Toast.LENGTH_SHORT).show();
                    break;
                }

            case R.id.about:
                Intent j = new Intent(getApplicationContext(),AboutUs.class);
                startActivity(j);
                break;
            case R.id.help:
                Intent k = new Intent(getApplicationContext(),AboutUs.class);
                startActivity(k);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    // Handle the Back Key
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setIcon(R.drawable.ic_sad)
                .setTitle(getString(R.string.exit_prompt_title))
                .setMessage(getString(R.string.exit_prompt_msg))
                .setPositiveButton(getString(R.string.exit_prompt_exit), new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton(getString(R.string.exit_prompt_cancel), null)
                .show();
    }
}
