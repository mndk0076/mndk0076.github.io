package mendozaassign1.prototypelabflow;

//Protoype Lab Flow by V/X Estate
//Kenneth Mendoza(N00587007)
//Sukhdeep Sehra (N01046228)
//Matheus Almeida (N00739768)

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class RegisterActivity extends LoginActivity {

    EditText etName, etStudentNumber, etUsername, etPassword;
    String name, studentNumber, username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        android.support.v7.app.ActionBar ab = getSupportActionBar();
        ab.setTitle(" " + getString(R.string.registration_screen));
        ab.setDisplayUseLogoEnabled(false);
        ab.setDisplayShowHomeEnabled(true);

        etName = (EditText) findViewById(R.id.etName);
        etStudentNumber = (EditText) findViewById(R.id.etStudentNumber);
        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
    }

    public void userReg(View view){
        name = etName.getText().toString();
        studentNumber = etStudentNumber.getText().toString();
        username = etUsername.getText().toString();
        password = etPassword.getText().toString();

        String method = "register";
        RegisterRequest registerRequest = new RegisterRequest(this);
        registerRequest.execute(method, name, studentNumber, username, password);
        finish();
    }
}
