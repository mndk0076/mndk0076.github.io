package mendozaassign1.prototypelabflow;

//Protoype Lab Flow by V/X Estate
//Kenneth Mendoza(N00587007)
//Sukhdeep Sehra (N01046228)
//Matheus Almeida (N00739768)

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class RequestItemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_item);
        android.support.v7.app.ActionBar ab = getSupportActionBar();
        ab.setTitle(" " + getString(R.string.reqitem_screen));
        ab.setDisplayUseLogoEnabled(true);
        ab.setDisplayShowHomeEnabled(true);
    }

    public void tvContinue (View view){
        Intent intent = new Intent(this, ConfirmationActivity.class);
        startActivity(intent);
    }
}
