package mendozaassign1.prototypelabflow;

//Protoype Lab Flow by V/X Estate
//Kenneth Mendoza(N00587007)
//Sukhdeep Sehra (N01046228)
//Matheus Almeida (N00739768)


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);
        android.support.v7.app.ActionBar ab = getSupportActionBar();
        ab.setTitle(" " + getString(R.string.confirm_screen));
        ab.setDisplayUseLogoEnabled(true);
        ab.setDisplayShowHomeEnabled(true);
    }
}
