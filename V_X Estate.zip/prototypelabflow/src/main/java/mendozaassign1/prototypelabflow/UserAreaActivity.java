package mendozaassign1.prototypelabflow;

//Protoype Lab Flow by V/X Estate
//Kenneth Mendoza(N00587007)
//Sukhdeep Sehra (N01046228)
//Matheus Almeida (N00739768)

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class UserAreaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_area);
        android.support.v7.app.ActionBar ab = getSupportActionBar();
        ab.setLogo(R.mipmap.ic_launcher);
        ab.setTitle(" " + getString(R.string.home_screen));
        ab.setDisplayUseLogoEnabled(true);
        ab.setDisplayShowHomeEnabled(true);

        final EditText etName = (EditText) findViewById(R.id.etName);

    }

    public void scanIt(MenuItem view) {
        final Activity activity = this;
        IntentIntegrator integrator = new IntentIntegrator(activity);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
        integrator.setCameraId(0);
        integrator.setBeepEnabled(false);
        integrator.setBarcodeImageEnabled(false);
        integrator.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(result != null){
            if(result.getContents()==null){
                Toast.makeText(this, (R.string.scan_cancelled), Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(this, result.getContents(),Toast.LENGTH_LONG).show();
            }
        }
        else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.admin_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {
            case R.id.theme:
                //  Toast.makeText(this, "changing theme", Toast.LENGTH_SHORT).show();
                //       int id = item.getItemId();


                if(item.isChecked()){
                    item.setChecked(false);
                    Toast.makeText(this, (R.string.change_theme1), Toast.LENGTH_SHORT).show();
                    //        setTheme(R.id.AppTheme);
                    break;
                }else{
                    item.setChecked(true);
                    Toast.makeText(this, (R.string.change_theme2), Toast.LENGTH_SHORT).show();
                    break;
                }

            case R.id.about:
                Intent j = new Intent(getApplicationContext(),AboutUs.class);
                startActivity(j);
                break;
            case R.id.help:
                Intent k = new Intent(getApplicationContext(),AboutUs.class);
                startActivity(k);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void tvRequest (View view){
        Intent intent = new Intent(this, RequestItemActivity.class);
        startActivity(intent);
    }
}
