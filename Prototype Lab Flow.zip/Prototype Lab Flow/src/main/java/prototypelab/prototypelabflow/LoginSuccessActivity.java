package prototypelab.prototypelabflow;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginSuccessActivity extends AppCompatActivity {
    TextView first_name,username;
    String FirstName;
    TabLayout tabLayout;
    ViewPager viewPager;
    String json_url = "http://prototypelabflow.esy.es/Login.php";
    AlertDialog.Builder builder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        /*
        first_name = (TextView)findViewById(R.id.first_name);
        username =(TextView)findViewById(R.id.username);
        Bundle bundle = getIntent().getExtras();
        first_name.setText("Welcome "+bundle.getString("first_name"));
        username.setText("Last Name " +bundle.getString("last_name"));
        first_name = (TextView)view.findViewById(R.id.first_name);
        username =(TextView)view.findViewById(R.id.username);
        //Bundle bundle = getActivity().getIntent().getExtras();

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, json_url, (String) null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    first_name.setText(response.getString("first_name"));
                    username.setText(response.getString("username"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(),"Error",Toast.LENGTH_LONG).show();
                error.printStackTrace();
            }
        });
        MySingleton.getMyInstance(getActivity()).addToRequestque(jsonObjectRequest);
        */
        first_name = (TextView)findViewById(R.id.first_name);
        Bundle bundle = getIntent().getExtras();
        first_name.setText("Welcome "+bundle.getString("first_name"));
        builder = new AlertDialog.Builder(LoginSuccessActivity.this);

        Button profile;
        profile = (Button)findViewById(R.id.profile);
        profile.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                FirstName = first_name.getText().toString();

                StringRequest stringRequest = new StringRequest(Request.Method.POST, json_url, new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response){
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            JSONObject jsonObject = jsonArray.getJSONObject(0);
                            String code = jsonObject.getString("code");
                            if(code.equals("login_failed")) {
                                builder.setTitle("Login Failed");
                                //displayAlert(jsonObject.getString("message"));
                            } else{
                                Intent intent = new Intent(LoginSuccessActivity.this, ProfileActivity.class);
                                Bundle bundle = new Bundle();
                                bundle.putString("first_name", jsonObject.getString("first_name"));
                                bundle.putString("last_name", jsonObject.getString("last_name"));
                                intent.putExtras(bundle);
                                startActivity(intent);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error){
                        Toast.makeText(LoginSuccessActivity.this, "Error",Toast.LENGTH_LONG).show();
                        error.printStackTrace();
                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("first_name", FirstName);
                        return params;
                    }
                };
                MySingleton.getMyInstance(LoginSuccessActivity.this).addToRequestque(stringRequest);

            }
        });

    }
/*
    public void profile(View view) {
        Intent intent = new Intent(LoginSuccessActivity.this, ProfileActivity.class);
        Bundle bundle = getIntent().getExtras();
        intent.putExtras(bundle);
        startActivity(intent);

    }
    */
}
